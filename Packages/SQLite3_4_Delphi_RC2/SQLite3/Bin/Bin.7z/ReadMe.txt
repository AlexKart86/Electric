Needed files:
sqlite3.dll is needed for Windows only.
It's already included in OSX.
test.db, Sunset.jpg - database files for unit tests
